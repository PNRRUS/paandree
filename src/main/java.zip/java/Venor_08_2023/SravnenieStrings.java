package Venor_08_2023;

import java.util.Scanner;

public class SravnenieStrings {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    String firstString = input.nextLine();
    String secondString = input.nextLine();
System.out.println(firstString.equals(secondString));
    }
}
