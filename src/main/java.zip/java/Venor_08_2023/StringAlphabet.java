package Venor_08_2023;

import java.util.Scanner;

public class StringAlphabet {
        public static void main(String[] args){
//    Scanner input = new Scanner(System.in);
//    String words = input.nextLine();
    double c = 12.235452456002;
            float a = 12.7555f;
//        System.out.print(words.charAt(0) <  words.charAt(words.indexOf(" ") + 1));
            System.out.print((float) c);
}
}