package Venor_08_2023;

import java.util.Scanner;

public class AddStrings {
        public static void main(String[] args)
{
//    Scanner vvod = new Scanner(System.in);
//    String string1 = vvod.nextLine();
//    String string2 = vvod.nextLine();
//    String stroka2and1 = string2 + " " + string1;
//    int numberOfLetters = stroka2and1.length();
//        System.out.println(string1 + " " +  string2);
//        System.out.println("number of letters " + numberOfLetters);

    int x = 11, y = 20;

    System.out.println(x + 1 + " не равно " + y);   //12 не равно 20
    System.out.println(x + " не равно " + y + 1);   //11 не равно 201
    System.out.println(x + " не равно " + (y + 1)); //11 не равно 21
}
}
