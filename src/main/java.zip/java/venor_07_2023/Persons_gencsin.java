package venor_07_2023;

public class Persons_gencsin {

    int Silla; // сила персонажа
    int HP; // хп персонажа

    // создание персонажа по конкретным данным - конструктор
    public Persons_gencsin(int Silla, int HP) {
        this.Silla = Silla;
        this.HP = HP;
    }

    // повесить артефакт - здоровье персонажа увеличется на 1536 очков хп
    public void instrykter(int point) {
        HP = HP + point;
    }

    // повесить артефакт - сила персонажа увеличется на 192 очков силы
    public void isymrudnai_teni(int point) {

        Silla = Silla + point;
    }

    // снять артефакт инструктер - минус 1536 очков хп
    public void id() {

        Silla = 0;
}
    }
