package venor_07_2023;

import javax.swing.*;

public class Interteilar {

    public static void main(String[] args) {

        Persons_gencsin Tignary = new Persons_gencsin(782, 21356);
        Persons_gencsin Siun_li = new Persons_gencsin(756, 11256);
        Persons_gencsin Saxarosa = new Persons_gencsin(745, 12458);

        Tignary.instrykter(100537);
        Siun_li.instrykter(1536);
        Siun_li.isymrudnai_teni(192);
        Saxarosa.id();


        System.out.println("здоровье Тигнари " + Tignary.HP + " " + "сила " + Tignary.Silla);
        System.out.println("здоровье Сян Лин " + Siun_li.HP + " " + "сила " + Siun_li.Silla);
        System.out.println("здоровье Сахарозы " + Saxarosa.HP + " " + "сила " + Saxarosa.Silla);


        JOptionPane.showMessageDialog(null,
                    "здоровье Тигнари " + Tignary.HP + " " + "сила " + Tignary.Silla
                        + "\n" + "здоровье Сян Лин " + Siun_li.HP + " " + "сила " + Siun_li.Silla
                        + "\n" + "здоровье Сахарозы " + Saxarosa.HP + " " + "сила " + Saxarosa.Silla
        );

        System.exit(0);

    }
}
