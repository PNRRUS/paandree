class Sandbox {
    public static void main(String[] args) {

//        String name = "Ivan";
//        int age = 25;
//        double height = 1.85;
//        System.out.println(name);
//        System.out.println(age);
//        System.out.println(height);
        //System.out.println();
        //System.out.println(1 + 56);
        //System.out.print("\033[2J" + 5);
        //Thread.sleep(1400);
       //System.out.println("для завершения - нажмите на мигающую иконку джава справа в строке приложений");
        //Icon imageIcon = new ImageIcon("D:/Downloads/pepe.gif_");
        //JLabel label = new JLabel(imageIcon);
        //JFrame frame = new JFrame("pepe");
        //frame.getContentPane().add(label);
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       //frame.pack();
        //frame.setVisible(true);
            }
}
