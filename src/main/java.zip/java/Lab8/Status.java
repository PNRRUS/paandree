package Lab8;

public enum Status {
    NEGATIVE,
    ZERO,
    POSITIVE
}
