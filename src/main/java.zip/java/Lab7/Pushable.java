package Lab7;

interface Pushable {
        boolean push(double v);
}
